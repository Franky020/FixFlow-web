import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-AIYP2IWR.js";
import "./chunk-NTOGRT2P.js";
import "./chunk-REBW6CQF.js";
import "./chunk-6NWCHYE3.js";
import "./chunk-2MBKP3H7.js";
import "./chunk-TOF6LNKI.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
